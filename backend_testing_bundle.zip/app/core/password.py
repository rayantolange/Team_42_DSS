from passlib.context import CryptContext

pwd_context = CryptContext(
    schemes=["bcrypt"],
    deprecated="auto"
)


def hash_password(plain_password: str) -> str:
    """
    Hash a plain text password.
    """
    return pwd_context.hash(plain_password)


def verify_password(
    plain_password: str,
    hashed_password: str
) -> bool:
    """
    Verify a password against a bcrypt hash.
    """
    return pwd_context.verify(
        plain_password,
        hashed_password
    )